﻿namespace TestThread1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_ThreadStart = new System.Windows.Forms.Button();
            this.Btn_ThreadAbt = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btn_ThreadStart
            // 
            this.Btn_ThreadStart.Location = new System.Drawing.Point(13, 40);
            this.Btn_ThreadStart.Name = "Btn_ThreadStart";
            this.Btn_ThreadStart.Size = new System.Drawing.Size(139, 23);
            this.Btn_ThreadStart.TabIndex = 0;
            this.Btn_ThreadStart.Text = "Thread Start";
            this.Btn_ThreadStart.UseVisualStyleBackColor = true;
            this.Btn_ThreadStart.Click += new System.EventHandler(this.Btn_ThreadStart_Click);
            // 
            // Btn_ThreadAbt
            // 
            this.Btn_ThreadAbt.Location = new System.Drawing.Point(13, 69);
            this.Btn_ThreadAbt.Name = "Btn_ThreadAbt";
            this.Btn_ThreadAbt.Size = new System.Drawing.Size(139, 23);
            this.Btn_ThreadAbt.TabIndex = 1;
            this.Btn_ThreadAbt.Text = "Thread Abort";
            this.Btn_ThreadAbt.UseVisualStyleBackColor = true;
            this.Btn_ThreadAbt.Click += new System.EventHandler(this.Btn_ThreadAbt_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(13, 116);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 19);
            this.textBox1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Btn_ThreadAbt);
            this.Controls.Add(this.Btn_ThreadStart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_ThreadStart;
        private System.Windows.Forms.Button Btn_ThreadAbt;
        private System.Windows.Forms.TextBox textBox1;
    }
}

