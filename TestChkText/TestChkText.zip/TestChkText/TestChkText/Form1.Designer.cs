﻿namespace TestChkText
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Btn_ChkTxt1 = new System.Windows.Forms.Button();
            this.Btn_ChkTxt3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.Btn_ChkTxt5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "a to z only";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(127, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(117, 19);
            this.textBox1.TabIndex = 1;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox2.Location = new System.Drawing.Point(283, 30);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(32, 19);
            this.textBox2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "a to z and  0-9 only";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(127, 70);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(117, 19);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox4.Location = new System.Drawing.Point(283, 70);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(32, 19);
            this.textBox4.TabIndex = 5;
            // 
            // Btn_ChkTxt1
            // 
            this.Btn_ChkTxt1.Location = new System.Drawing.Point(321, 30);
            this.Btn_ChkTxt1.Name = "Btn_ChkTxt1";
            this.Btn_ChkTxt1.Size = new System.Drawing.Size(75, 23);
            this.Btn_ChkTxt1.TabIndex = 6;
            this.Btn_ChkTxt1.Text = "Check";
            this.Btn_ChkTxt1.UseVisualStyleBackColor = true;
            this.Btn_ChkTxt1.Click += new System.EventHandler(this.Btn_ChkTxt1_Click);
            // 
            // Btn_ChkTxt3
            // 
            this.Btn_ChkTxt3.Location = new System.Drawing.Point(321, 70);
            this.Btn_ChkTxt3.Name = "Btn_ChkTxt3";
            this.Btn_ChkTxt3.Size = new System.Drawing.Size(75, 23);
            this.Btn_ChkTxt3.TabIndex = 7;
            this.Btn_ChkTxt3.Text = "Check";
            this.Btn_ChkTxt3.UseVisualStyleBackColor = true;
            this.Btn_ChkTxt3.Click += new System.EventHandler(this.Btn_ChkTxt3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "AtoZ tab space only";
            // 
            // textBox5
            // 
            this.textBox5.AcceptsTab = true;
            this.textBox5.Location = new System.Drawing.Point(127, 111);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(117, 19);
            this.textBox5.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox6.Location = new System.Drawing.Point(283, 111);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(32, 19);
            this.textBox6.TabIndex = 10;
            // 
            // Btn_ChkTxt5
            // 
            this.Btn_ChkTxt5.Location = new System.Drawing.Point(321, 111);
            this.Btn_ChkTxt5.Name = "Btn_ChkTxt5";
            this.Btn_ChkTxt5.Size = new System.Drawing.Size(75, 23);
            this.Btn_ChkTxt5.TabIndex = 11;
            this.Btn_ChkTxt5.Text = "Check";
            this.Btn_ChkTxt5.UseVisualStyleBackColor = true;
            this.Btn_ChkTxt5.Click += new System.EventHandler(this.Btn_ChkTxt5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 179);
            this.Controls.Add(this.Btn_ChkTxt5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Btn_ChkTxt3);
            this.Controls.Add(this.Btn_ChkTxt1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_ChkTxt1;
        private System.Windows.Forms.Button Btn_ChkTxt3;
        private System.Windows.Forms.Button Btn_ChkTxt5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label3;
    }
}

